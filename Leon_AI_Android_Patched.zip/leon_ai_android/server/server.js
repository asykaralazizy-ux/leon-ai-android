import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import rateLimit from "express-rate-limit";

dotenv.config();
const app = express();
const port = Number(process.env.PORT || 3000);
app.disable("x-powered-by");
app.use(cors());
app.use(express.json({ limit: "8mb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: true, legacyHeaders: false }));

app.get("/health", (_req, res) => res.json({ ok: true, app: "Leon AI backend", provider: process.env.AI_PROVIDER || "gemini" }));

function validateRequest(body) {
  const { message, image } = body || {};
  if (typeof message !== "string" || !message.trim()) return "Pesan tidak boleh kosong.";
  if (message.length > 12000) return "Pesan terlalu panjang (maksimal 12.000 karakter).";
  if (image && (typeof image !== "string" || !/^data:image\/(png|jpeg|webp);base64,/.test(image) || image.length > 6_000_000)) {
    return "Gambar harus PNG, JPG, atau WEBP dan ukurannya di bawah sekitar 4 MB.";
  }
  return null;
}

async function askGemini({ key, model, message, image, instructions, useWebSearch }) {
  const parts = [{ text: message.trim() }];
  if (image) {
    const match = image.match(/^data:(image\/(?:png|jpeg|webp));base64,(.+)$/);
    if (!match) throw new Error("Format gambar tidak didukung.");
    parts.push({ inlineData: { mimeType: match[1], data: match[2] } });
  }
  const payload = { systemInstruction: { parts: [{ text: instructions }] }, contents: [{ role: "user", parts }] };
  if (String(process.env.ENABLE_WEB_SEARCH).toLowerCase() !== "false" && useWebSearch === true) {
    payload.tools = [{ google_search: {} }];
  }
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": key },
    body: JSON.stringify(payload)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const msg = data?.error?.message || `Gemini API gagal (HTTP ${response.status}).`;
    const error = new Error(msg); error.status = response.status; throw error;
  }
  return (data.candidates?.[0]?.content?.parts || []).map(p => p.text || "").filter(Boolean).join("\n").trim();
}

async function askOpenAI({ key, model, message, image, instructions, useWebSearch }) {
  const content = [{ type: "input_text", text: message.trim() }];
  if (image) content.push({ type: "input_image", image_url: image });
  const payload = { model, instructions, input: [{ role: "user", content }] };
  if (String(process.env.ENABLE_WEB_SEARCH).toLowerCase() !== "false" && useWebSearch === true) payload.tools = [{ type: "web_search" }];
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST", headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/json" }, body: JSON.stringify(payload)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data?.error?.message || `OpenAI API gagal (HTTP ${response.status}).`);
    error.status = response.status; throw error;
  }
  return data.output_text || (data.output || []).flatMap(item => item.content || []).filter(item => item.type === "output_text").map(item => item.text).join("\n");
}

app.post("/api/chat", async (req, res) => {
  try {
    const validationError = validateRequest(req.body);
    if (validationError) return res.status(400).json({ error: validationError });

    const { message, image, personality, assistantName, useWebSearch } = req.body;
    const provider = String(process.env.AI_PROVIDER || "gemini").toLowerCase();
    const key = provider === "openai" ? process.env.OPENAI_API_KEY : process.env.GEMINI_API_KEY;
    if (!key) {
      return res.status(503).json({ error: provider === "openai"
        ? "API belum siap: isi OPENAI_API_KEY pada environment backend. Jangan masukkan key ke aplikasi Android."
        : "API belum siap: buat API key Gemini dan isi GEMINI_API_KEY pada environment backend. Jangan masukkan key ke aplikasi Android." });
    }
    if (!['gemini', 'openai'].includes(provider)) return res.status(500).json({ error: "AI_PROVIDER harus bernilai gemini atau openai." });

    const name = String(assistantName || "Leon AI").slice(0, 40);
    const persona = String(personality || "Ramah, jelas, jujur, dan membantu.").slice(0, 1000);
    const instructions = `Kamu adalah ${name}, asisten AI yang dikustomisasi pengguna. Kepribadian: ${persona}. Jawab dalam bahasa yang digunakan pengguna. Bantu membuat dan menjelaskan kode dengan format code block. Jujur tentang ketidakpastian dan jangan mengaku melakukan tindakan yang belum dilakukan.`;
    const model = provider === "openai" ? (process.env.OPENAI_MODEL || "gpt-4.1-mini") : (process.env.GEMINI_MODEL || "gemini-3.8-flash");
    const answer = provider === "openai"
      ? await askOpenAI({ key, model, message, image, instructions, useWebSearch })
      : await askGemini({ key, model, message, image, instructions, useWebSearch });
    return res.json({ answer: answer || "AI tidak mengembalikan teks. Coba lagi." });
  } catch (err) {
    console.error("Leon AI request failed:", err.message);
    const status = err.status === 429 ? 429 : err.status === 400 ? 400 : 502;
    return res.status(status).json({ error: err.message || "Server mengalami masalah. Periksa log backend." });
  }
});

app.listen(port, "0.0.0.0", () => console.log(`Leon AI backend running on port ${port}`));
