# Leon AI Android — panduan HP saja

Proyek starter aplikasi Android dengan UI chat, upload gambar, kustomisasi nama/kepribadian/tema, tombol web search, dan dukungan TTS/voice recognition bergantung pada WebView perangkat. Backend mendukung Gemini API (default) atau OpenAI API. Proyek ini belum merupakan aplikasi produksi dan belum diuji pada HP pengguna.

## PENTING: bedakan build APK dan AI online
- **APK bisa dibangun tanpa API key.** API key tidak diperlukan untuk compile aplikasi.
- **AI online tidak bisa menjawab tanpa backend yang online dan API key yang valid.** Backend menyimpan key; jangan pernah menaruh key di HTML, APK, repo publik, atau chat.
- Model/kuota/API bisa berubah. Backend default menggunakan Gemini `gemini-3.8-flash`; ubah `GEMINI_MODEL` jika model itu tidak tersedia untuk project API-mu.

## A. Membuat APK dari HP Android saja
Cara termudah tanpa memasang Android Studio di HP adalah memakai GitHub Actions sebagai build cloud.

1. Ekstrak ZIP proyek di HP menggunakan pengelola file.
2. Buka GitHub di browser dan buat repository baru bernama `leon-ai-android`. Untuk menghindari kebocoran, jangan masukkan file `.env` atau API key. Repo boleh public karena tidak ada secret di kode sumber.
3. Unggah semua ISI folder proyek ke root repository, termasuk folder tersembunyi `.github/workflows/`, `android/`, `server/`, dan `README.md`. Pastikan `android/` berada di root, bukan `leon_ai_android/android/android`.
4. Setelah file terunggah, buka tab **Actions** di repository. Pilih workflow **Build Leon AI APK** lalu **Run workflow**. Jika workflow tidak terlihat, pastikan file `.github/workflows/build-apk.yml` terunggah dengan benar dan Actions diizinkan.
5. Tunggu job selesai. Jika berhasil, buka run tersebut, cari bagian **Artifacts**, lalu unduh `Leon-AI-debug-APK`.
6. Ekstrak artefak ZIP, lalu ketuk `app-debug.apk`. Android mungkin meminta izin **Install unknown apps** untuk browser/file manager yang kamu pakai. Hanya pasang APK yang dibangun dari kode yang kamu percaya.
7. APK ini adalah debug build untuk uji coba, bukan rilis Play Store. Workflow cloud memakai Java 17 dan Gradle 8.9 untuk proyek Android Gradle Plugin 8.7.3.

## B. Membuat backend dari HP
Kamu perlu layanan hosting yang dapat menjalankan Node.js dan menyediakan environment variables. Di browser HP:

1. Buat API key di Google AI Studio: https://aistudio.google.com/app/apikey. Ketersediaan model dan batas gratis tergantung akun, region, dan aturan terbaru. Jangan bagikan key.
2. Deploy folder `server/` ke hosting Node.js yang mendukung Node 20+ dan environment variables. Unggah `server.js` dan `package.json`; jalankan `npm install` saat build/deploy dan `npm start` saat start.
3. Tambahkan environment variable di dashboard hosting:
   - `AI_PROVIDER` = `gemini`
   - `GEMINI_API_KEY` = API key yang baru kamu buat
   - `GEMINI_MODEL` = `gemini-3.8-flash` (ganti bila tidak tersedia)
   - `ENABLE_WEB_SEARCH` = `true`
   - `PORT` biasanya diatur otomatis oleh hosting; jangan hardcode bila platform mengatur sendiri.
4. Deploy. Buka `https://ALAMAT-SERVER-KAMU/health`. Respons yang diharapkan berisi `"ok":true`. Ini hanya tes server, bukan tes model API.
5. Di aplikasi Leon AI, buka ⚙ Pengaturan, isi URL server HTTPS tanpa garis miring di ujung, misalnya `https://nama-app.hosting.example`, lalu Simpan.
6. Kirim pesan uji: `Balas hanya dengan kata LEON BERHASIL`. Aktifkan tombol Web hanya saat ingin mencoba pencarian web.

**Hosting gratis dapat tidur, membatasi pemakaian, atau berubah kebijakannya.** Jangan unggah API key ke repo GitHub. Untuk aplikasi yang dipakai orang lain, tambahkan autentikasi pengguna, batas pemakaian per akun, dan kebijakan privasi.

## C. Memakai OpenAI sebagai alternatif
Setel `AI_PROVIDER=openai`, `OPENAI_API_KEY` pada environment server, dan `OPENAI_MODEL` ke model yang tersedia untuk project API-mu. Jangan menyimpan key di aplikasi Android. Pemakaian API dapat dikenai biaya.

## D. Diagnostik
- **APK gagal dibangun:** buka Actions → workflow run → job build → salin baris error pertama yang relevan. Pastikan file `android/settings.gradle`, `android/build.gradle`, dan `android/app/build.gradle` ada.
- **Aplikasi bilang backend belum diatur:** buka ⚙ dan isi URL backend HTTPS.
- **Failed to fetch:** URL salah, backend tidur/down, sertifikat HTTPS bermasalah, atau koneksi internet putus.
- **503 API belum siap:** environment variable key tidak diatur di hosting atau salah nama.
- **400 model tidak ditemukan / invalid argument:** model tidak tersedia atau fitur tidak didukung; ubah `GEMINI_MODEL` ke model yang tercantum di dokumentasi akun API.
- **401/403:** API key/akses tidak valid. Buat atau atur ulang key melalui dashboard resmi, lalu perbarui environment variable hosting.
- **429:** batas pemakaian terlampaui; tunggu/reset kuota atau periksa batas akun.
- **Web search gagal:** matikan tombol Web untuk memastikan chat dasar berjalan; dukungan grounding/search bergantung model dan akun.
- **Voice tidak bekerja:** browser speech recognition tidak tersedia di semua WebView. Gunakan keyboard; TTS juga tergantung suara yang terpasang pada Android.
- **Gambar tidak diterima:** gunakan PNG/JPG/WEBP kecil (sekitar di bawah 4 MB).

## E. Batasan keamanan dan teknis
- Ini adalah aplikasi berbasis WebView; bukan model AI yang dilatih sendiri.
- Key harus berada di backend, tidak di APK.
- Endpoint saat ini memiliki rate limit sederhana tetapi belum mempunyai login/authentication. Jangan membuka endpoint publik untuk penggunaan ramai tanpa pengamanan tambahan.
- Manifest mengizinkan HTTP untuk pengujian LAN. Untuk produksi, gunakan HTTPS dan sebaiknya nonaktifkan cleartext traffic.
- UI menyimpan pengaturan di localStorage WebView. Riwayat chat belum disimpan sebagai database.
- Belum ada streaming token, akun pengguna, sinkronisasi lintas perangkat, atau paket rilis signed.
